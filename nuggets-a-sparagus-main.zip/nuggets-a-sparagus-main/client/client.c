/* client.c 
 * 
 * This module allows an individual to join the 'nuggets' game as a player or
 * spectator. It takes initial commandline arguments, then interacts with the 
 * user through keypresses. 
 *
 * a-sparagus, May 2021 
 * CS50 
 */


#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ncurses.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <math.h>
#include "message.h"


bool handleMessage(void* arg, const addr_t from, const char* message);
bool handleInput(void* arg);
static void windowSize(int nrows, int ncols);
static void sendKey(char key, addr_t addr);


typedef struct letp
{
  int nc;
  char letter;
  int n;
  int r;
  int p;
  int currx;
  int curry;
} letp_t;

letp_t* poslet;
 
int main(const int argc, char* argv[]) {
  char* hostname;
  char* port;
  char* playername;
  addr_t addr;

  // parse and validate arguments
  if (argc < 3 || argc > 5) {
    fprintf(stderr, "Incorrect number of command line arguments.\n");
    return 1;
  } else if (argc == 4) {
    playername = (char*)malloc(strlen(argv[3]));
    sprintf(playername, "%s", argv[3]);
  } else if (argc == 5) {
    playername = (char*)malloc(strlen(argv[3]) + strlen(argv[4]) + 1);
    sprintf(playername, "%s %s", argv[3], argv[4]);
  }
  hostname = argv[1];
  port = argv[2];

  poslet = (letp_t*)malloc(sizeof(letp_t));
  poslet->letter = ' ';
  poslet->nc = 0;
  poslet->r = 0;
  poslet->n = 0;
  poslet->p = 0;
  poslet->currx = 0;
  poslet->curry = 0;

  message_init(stderr);                              // initializes module and returns client port
  if (message_setAddr(hostname, port, &addr)) {      // if it was successful in initializing the adddress
    if (argc > 3) {                                  // if the client is joining as a player
      char message[strlen(playername) + 5];
      sprintf(message, "PLAY %s", playername);
      message_send(addr, message); 
    } else {                                         // if the player is joining as a spectator
      char message[9];
      sprintf(message, "SPECTATE");
      message_send(addr, message);
    }
  } else {
    fprintf(stderr, "ERROR in initializing address.\n");
    return 1;                                        // return nonzero on error
  }

  // to accept keystrokes from user
  initscr();
  // to make the letters yellow and the background black
  start_color();
  init_pair(1, COLOR_YELLOW, COLOR_BLACK);
  attron(COLOR_PAIR(1));

  cbreak();
  noecho(); 
 
  message_loop(&addr, 0, NULL, handleInput, handleMessage);
  message_done(); 
  
  if (argc == 4 || argc == 5) {
    free(playername);                               // free malloc'd playername string
  }
  free(poslet);
  return 0;
}


// Calls the appropriate function or executes the command according to the message recieved
bool handleMessage(void* arg, const addr_t from, const char* message) {

  if (strncmp(message, "OK ", strlen("OK ")) == 0) {                        // to get the player letter for during the game 
    char* content = (char*)message + strlen("OK ");
    sscanf(content, "%c", &(poslet->letter));
  }
  
  if (strncmp(message, "GRID ", strlen("GRID ")) == 0) {               // if a new client
   char* content = (char*)message + strlen("GRID ");
   int nrows, ncols;                                                  // initialize nrows and ncols
   sscanf(content, "%d %d", &nrows, &ncols);                          // parse the message for the ints
   poslet->nc = ncols;
   windowSize(nrows + 1, ncols);                                              
  }
  
  if (strncmp(message, "GOLD ", strlen("GOLD ")) == 0) {              // info about gold collected and left
    char* content = (char*)message + strlen("GOLD ");
    sscanf(content, "%d %d %d", &(poslet->n), &(poslet->p), &(poslet->r));
  }

  if (poslet->letter == ' ') {
      mvprintw(0, 0, "Spectator: %d nuggets unclaimed. Play at plank\n", poslet->r);
    } else {
      mvprintw(0, 0, "Player %c has %d nuggets (%d nuggets unclaimed). GOLD recieved: %d\n", poslet->letter, poslet->n, poslet->r, poslet->p);
  }
  
  if (strncmp(message, "DISPLAY\n", strlen("DISPLAY\n")) == 0) {      // to produce game to user
    char *content = (char*)message + strlen("DISPLAY\n");
    mvprintw(1, 0, "%s", content);
    for (int i = 0; i < strlen(content); i++) {
      if (content[i] == '@') {
        int y = floor(i/(double)(poslet->nc + 1));
        poslet->currx = i - (y * ((poslet->nc) + 1));
        poslet->curry = y + 1;
        break;
      }
    }
  }
  
  if (strncmp(message, "QUIT ", strlen("QUIT ")) == 0) { 
    char* content = (char*)message + strlen("QUIT ");
    endwin();
    printf("%s\n", content);
    return true;
  }

  if (strncmp(message, "ERROR ", strlen("ERROR ")) == 0) {            // if error
    move(0, 0);
    clrtoeol();
    mvprintw(0, 0, "%s", message);
  }

  move(poslet->curry, poslet->currx);
  refresh();
  return false;
}


bool handleInput(void* arg) {
  addr_t* addr = arg;
  char c = getch();
  sendKey(c, *addr);
  return false;
}


// Checks that the display window is the appropriate size for the map given from the server
static void windowSize(int nrows, int ncols) {
  int curr_x, curr_y;
  getmaxyx(stdscr, curr_x, curr_y);
  while (curr_x < nrows || curr_y < ncols) {                // checks if the getx/gety is less than the nrows/ncols
    mvprintw(0, 0, "Your window must be at least %d high \nYour window must be at least %d wide \nResize your window, then press 'Enter' to continue.\n", nrows, ncols);
    char resize;
    while ((resize = getch()) != 10) {
      ;                                                    // waits for the user to change the windowsize
    }
    getmaxyx(stdscr, curr_x, curr_y);                      // getmaxyx with current x and y
  }
}


// Compiles the message for when a user presses a key
static void sendKey(char key, addr_t addr) {
  char* message = malloc(5);                            // initialize messsage
  sprintf(message, "KEY %c", key);                      // compiles message
  message_send(addr, message);                          // sends message to server
}
