# NUGGETS CLIENT DESIGN
## CLIENT DESIGN SPEC

This document will describe the design of the nuggets client. The spec will cover the following decompositions:

- User interface;
- Inputs and outputs;
- Functional decomposition into functions/modules;
- Major data structures;
- High-level pseudo code for logic and algorithmic flow;
- Testing plan, including unit tests, integration tests, system tests.

### User Interface

As described in the [Requirements Spec](REQUIREMENTS.md), the client's first interface with the user is on the command-line; it must always have two or three arguments.
```bash
./player hostname port [playername] 
```
The third parameter is optional. If provided, the client is a player and this is their playername. If not provided, they will be the spectator. If there is a current spectator they will be booted off.

The client sends information to the server regarding user's keystrokes. As a player the user is able to navigate through the map using keys. Keystrokes are processed in "character-oriented mode"; user does not need to put a new line ("return") in between keystrokes. 

The server sends the client updated grid displays and player locations and the client is responsible for displaying information to the user.

### Inputs & Outputs

Once player credentials are validated by the server the, player receives information regarding the GRID layout and GOLD amount from the server. 

Client sends server updates on individual player location and receives updates to grid display and all player locations.


### Functional Decomposition
1. *parseArgs*, which will interpret and validate command-line arguments
2. *launchCheck* player sends "PLAY real name" to the server and waits for a response
3. *launch* player gets GRID and GOLD messages from server and displays information for user
4. *display* take in grid parameter and player location from server and displays it for user

### Major Data Structures
- *grid*, containing information about the current state of the game
- *player*, containing information about the client (if it is a player) and about what part of the game it can see


### Pseudo Code 

The nuggets-client will run as follows:

    Parse the command-line and validate paramenters using parseArgs
    Create local player and grid structures
    Send message to server with player name asking if it's okay to join
    When a message is received from server (for which client is continuously listening)
        Parse the message into letter indicating which player you are (or spectator), GRID and gold information 
        Call display function with updated grid and player
    When a keystroke is pressed by the user
        Parse the information into a message and send it to the server
    
    
### Testing Plan
#### Unit Tests
1. We propose to first test for the command-line with various forms of incorrect command-line arguments to ensure that the  command-line parsing and validation of those parameters, works correctly.
2. Next, we print out the port numbers to ensure that the networking units are working correctly
3. Additionally, we print out details of the allocated player to ensure that it has been initialized successfully
#### Integration Tests
1. We propose using the provided client and server in conjunction with our implementations to test communication between the two modules
2. Next, we will test out client initializing and testing against our server implementation

#### System Tests
We run a wide variety of tests using the compiled client and server aspects of our project, explicitly focusing on edge cases to ensure that our program is working. Essentially, we play the game!

### Design Addendum
For the division of work, we expect to have two individuals (Eve and Itish) working on the design and implementation of the data structures. Eve will work primarily on the grid module while Itish will work on the player and game modules. Hermilla will be working largely exclusively on the client design and Chahak will be working on the server implementation. Since the client module is relatively simple, Hermilla will join Chahak in integrating the server, client and game modules.