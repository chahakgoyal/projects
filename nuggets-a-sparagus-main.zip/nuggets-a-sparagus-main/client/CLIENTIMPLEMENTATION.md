# NUGGETS CLIENT IMPLEMENTATION
## CLIENT IMPLEMENTATION SPEC

In this document we reference the [Requirements Specification](REQUIREMENTS.md) and [Design Specification](DESIGN.md) and focus on the implementation-specific decisions.

The spec will contain the following conditions:

-  Data structures
-  Control flow: pseudo code for overall flow, and for each of the functions
-  Detailed function prototypes and their parameters
-  Error handling and recovery
-  Testing plan

### Data Structures
We anticipate building one local structure `letp` to the retain several different data types given to the client either from the commandline or the server. We will later use this information to display specific information back to the user. 
* letp
    * int nc
    * int n
    * int p
    * int r
    * char letter
    * int currx
    * int curry

### Control flow
The client will be implemented in one file, client.c, with the following functions:

#### main
The main function calls parseArgs and initializes the other modules and display. It will also be refreshing the display when it has been updated.
```
Initialize the hostname, port, playername and address (for message_setAddr)
Parse the arguments from the commandline into the initialized variables
Initialize the message module
Set the address
    If successful
        Send the first message to the server (as either player or spectator)
Create a message loop to accept messages from server
Initialize ncurses to accept keystrokes
If one of the target keys are pressed
    Send a message to server (sendKey)
At the game's conclusion, end the message loop
End curses and return
```

#### handleInput
This function will be called with every press of the keystroke within the message loop and call sendKey.
```
Initialize the address to which the key will be send from the given argument
Get the character from ncurses
Call sendKey
```

#### handleMessage
This function calls the appropriate function or executes the command according to the message recieved
```
If the message begins with GRID (upon new client)
    Call windowSize() with nrows and ncols
If the message begins with GOLD
    Print message to user about collected nuggets (n), nuggets in the purse (p) and nuggets remaining to be found (r)
If the message begins with DISPLAY
    print the message to user
If the message begins with QUIT
    Exit curses, print the message (including summary) and a newline
If the message begins with ERROR
    Print the message to the user
```

#### windowSize
This function checks that the display window is the appropriate size for the map given from the server.
```
Get the boundaries of the screen from handleMessage
If they are less than than the grid's specs
    Inform user about the necessary window size
Return true if the window is large enough or has been adjusted accordingly
```

#### sendKey
This function compiles the message for when a user presses a key. It is called during in `main` when listening for keypresses.
```
Given the character c from the call
Create a message with KEY as the first element and the pressed key as second
Send this message to the server
```

### Other modules
#### support
We will leverage the support module for `message.c` to handle all the message compilation and distribution processes of the information coming to and from the client among Internet hosts. Messages are limited to UDP packet size, may be lost, and may be reordered, but require no connection setup or teardown.

### Function prototypes
#### client
```c
int main(const int argc, char* argv[]);
static void parseArgs(const int argc, char* argv[], 
    char** hostname, int* port, char** playername);
bool handleMessage(void* arg,
    const addr_t from, const char* message);
bool handleInput(void* arg);
bool windowSize(int nrows, int ncols);
static void sendKey(int character);
```

### Error handling and recovery

### Testing plan
#### Unit testing
We propose to first test for the command-line with various forms of incorrect command-line arguments to ensure that the command-line parsing and validation of those parameters, works correctly. The plan will test the following arguments: 

1. No arguments 
2. One argument 
3. More than four arguments
4. Invalid hostname
5. Invalid port

#### Integration/system testing
Because the client is implemented in one module, we propose to test it in totality by using it with the server module provided by the shared directory to ensure proper port and network connectivity. After that, we plan on testing with our own server to ensure that the entire system connects, communicates messages effectively, and displays the map correctly. This will essentially be a test of the overall functionality of the nuggets game (ie. playing the game). 

We will also be testing the individual functionalities of the client module.
- Test that the window of the display is appropriately sized (`windowSize`) 
- Test that the display is correctly printing the information given from the server (`display`)
- Test that the appropriate messages are sent when keys are pressed
- Test that the cursor follows the player's location (in different locations)

For the unit tests, we anticipate creating the following test file:

`clienttest.sh`

The integration testing will mainly be carried out via actually playing the game - both with the given server and our own implementation
