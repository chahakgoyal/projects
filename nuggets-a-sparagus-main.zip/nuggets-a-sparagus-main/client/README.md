# Client

This subdirectory contains the files needed to implement the player aspect of the nuggets game. It includes several files:
* client.c
* clienttest.sh
* clienttest.out
* CLIENTIMPLEMENTATION.md
* CLIENTDESIGN.md
* README.md
* Makefile
* .gitignore

Once the client has given the correct number of valid commandline arguments, they can interact with the game through keystrokes.

The spectator can quit (Q).
The player can quit (Q) and move the player with letter presses. The eight movement keys are shown relative to the player (@) below.

|     |     |     |
|:---:|:---:|:---:|
|  y  |  k  |  u  |
|  h  |  @  |  l  |
|  b  |  j  |  n  |

Once the game is complete or quit, a message or summary will be printed to the screen.

## compiling

To compile,
```
make
```

To clean,
```
make clean
```

Commandline arguments to initiate the program,
```
./client hostname port [playername] 
```
