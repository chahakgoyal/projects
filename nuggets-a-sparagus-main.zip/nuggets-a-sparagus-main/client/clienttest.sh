#!bin/bash                                                                                   
#                                                                                            
# Testing .sh file for client.c                                                             
#                                                                                            
# a-sparagus 2021                                                                            
# CS50

# No input
./client

# One argument
./client plank

# More than four arguments
./client plank 1234 player name etc 

# Invalid hostname
./client invalidplank 1234

# Invalid port
./client plank 0000

