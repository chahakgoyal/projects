# groupname - a-sparagus
# Nuggets Testing

### Client
For the testing of our client program, we conducted both unit and system/integration testing. For the former, we wrote a `clienttest.sh` file to ensure that the command-line parsing and validation of those parameters works correctly.

##### `clienttest.sh`
The client program's testing file contains the following commands.

* `./client`
* `./client plank`
* `./client plank 1234 player name etc`
* `./client invalidplank 1234`
* `./client plank 0000`

The outputs of these tests are listed below, in the same order as above, and can be found in `clienttest.out`.

* `Incorrect number of command line arguments.`
* `Incorrect number of command line arguments.`
* `Incorrect number of command line arguments.`
* `ERROR in initializing address.`
* `ERROR in initializing address.`

### Server
For the testing of our server program, we conducted both unit and system/integration testing. For the former, we executed a series of commands to ensure that the command-line parsing and validation of those parameters works correctly.

* `./server`
* `./server ~/cs50-dev/shared/nuggets/linux/maps/invalid.txt`
* `./server ~/cs50-dev/shared/nuggets/linux/maps/main.txt -3`
* `./server ~/cs50-dev/shared/nuggets/linux/maps/main.txt 3 invalid`

The output of the above commands are listed below, in order.

* `Incorrect number of arguments`
* `Cannot open file`
* `Seed must be a positive integer`
* `Incorrect number of arguments`

### Game
For the testing of our game struct, we wrote two files to ensure that the struct executes the full scope of the game.

##### `gridtest.c`
The file to test grid data structure contains a variety of tasks to test the scope of the grid's executability. The psuedocode is as follows:

```
Open a file from the commandline
Initialize a grid from that file
Print out the columns and rows
Create an empty grid from the initialized
Print out the columns and rows of the grid
Print out the grid with grid_print
Obtain a character from the grid
Set a character to the grid
Check the validity of the grid (written in the grid struct)
Get the grid in string format and print it
Test visibility
Delete the grid (both from the file and the previously empty one)
Create a new empty grid
Try to delete the grid

```

##### `gametest.c`
The file to test the game module contains a variety of tasks to test the scope of the game's executability. The psuedocode is as follows:
```
Open and file and initialize a game from it
Allocate totalGold and numGoldPiles
Test game_gold by checking for how much gold remains
Test game_randomGold
Test that the grid can display as a string
Test the movement of a player (up, down, left, right, diagonally)
Test the player's purse with game_playerPurse
Check for the number of players with game_numPlayers
Check for a spectator with game_spectator
Test game_nc and game_nr
Test movements of multiple players at once with game_update(down)
Check the visibility of the grid
    Move multiple players in multiple directions
Test game_delete
```

### Server/Client Integration
> For the test of the connection between the server and the client, we used both the provided server and client modules and our own.

#### Shared Client/Server
To first test the functionality of the client independently, we connected it with the provided server from the shared CS50 directory. 

We tested it with three maps, `main.txt`, `a-sparagus.txt` and `big.txt`, to test if the client executed the following functionalities:
* Quit and exit logfile redirection on key Q
* Properly display map as it is provided from the server
* Give command at the top according to assignment of the client (player or spectator)
* Inform the player when they have collected coins
* Print a summary of the game upon game's end
* Inform user if incorrect display size and wait for them to change it
* Display ERROR messages
* Send quit message to spectator if another one joins
* Remove a player from the map if they quit before game ends

For each of the two maps that we tested from the provided server, we joined as both a spectator and a player
```
./server ~cs50-dev/shared/nuggets/linux/maps/main.txt
./client plank 59425 2>player.log
./client plank 59425 player 2>player1.log

./server ~cs50-dev/shared/nuggets/linux/maps/big.txt
./client plank 48913 2>player.log
./client plank 48913 player 2>player1.log

./server ~cs50-dev/shared/nuggets/linux/maps/a-sparagus.txt
./client plank 35923 2> player.log
./client plank 35923 player 2> player1.log
```

---

We then tested the functionality of the server independently, connecting it with the provided client from the shared CS50 directory.

We tested with the same two maps, `main.txt` and `big.txt`, to test if the server executed the following functionalities:
* Player moves in the correct direction with the appropriate keypress
* The display is a proper reflection of the maps files used
* The visibility executes as per the requirements
* Players collect coins as they move, and those coins disappear from the display once they are collected
* Coins are randomly distributed in the map, as are the players when they first join
* Spectators can see the entirety of the map
* Game ends when all the coins are collected
+ all the functionalities mentioned in shared client/server + requirements functionalities


#### a-sparagus Client/Server
For the test of how our client and server works with each other, we followed similar tests as the above, with the addition of our own map file `a-sparagus.txt`

In order to ensure that the map file we created complied with the requirements for a map to be used for the nuggets game, we utilized the `checkmap` given from the shared directory whether our mapfile was valid. We also used the mapfile with the given server and client from the shared directory to see how it functioned/looked during a game.

We tested our client and server with the two map files from above and the new one we created to test if the server and client executed the following final functionalities:
* Multiple players (and a spectator) can join and play at once
* A spectator is ejected from the game when a new one joins
* Any updates or movements from any player is sent to all clients simultaneously
* Server creates and sends summary to all players when game ends
