/*
 * set.c - CS50 'set' module
 *
 * see set.h for more information
 *
 * Eve Wening, April 2021
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "set.h"

/****************** file-local global variables ********************/
/* none */

/****************** local types *******************/
typedef struct setnode {
    const char* key;                  // pointer to key for this item
    void* item;                 // pointer to data for this item
    struct setnode *next;       // link to the next node
} setnode_t;

/****************** global types ******************/
typedef struct set {
    struct setnode *head;       // head of the simple linked list of items in the set
} set_t; 

/****************** global functions **************/

/****************** local functions ***************/
static setnode_t* setnode_new(const char* key, void* item);

/******************** functions *******************/
/* create a new setnode struct */
static setnode_t* // struct is only visible within this file
setnode_new(const char* key, void* item)
{
    setnode_t* node = malloc(sizeof(setnode_t));

    if (node == NULL) {
        return NULL;                // error during malloc()
    } else {
        node->key = key;
        node->item = item;
        node->next = NULL;
        return node;
    }
}

/****************** set_new() *********************/
/* see set.h for description */
set_t* 
set_new(void) 
{
    set_t* set = malloc(sizeof(set_t));

    if (set == NULL) {
        return NULL;                //error allocating set
    } else {
        // initialize contents of set structure
        set->head = NULL;
        return set;
    }
}

/****************** set_insert() ********************/
/* see set.h for description */
bool
set_insert(set_t* set, const char* key, void* item)
{
    if (set == NULL || key == NULL || item == NULL) {   // false if any parameter returns NULL
        return false;
    }
    
    if (set_find(set, key) != NULL) { return false; }  // if this key alread exists, return false
    
    char* keyCopy = malloc(strlen(key)+1);               // key string copied for use by set
    strcpy(keyCopy, key);

    setnode_t* new = setnode_new(keyCopy, item);     // allocate and create a new node
    if (new != NULL) {                      // add new node to head of list if it was succesfully created
        new->next = set->head;
        set->head = new;
        return true;
    } else {
        return false;
    }
}

/***************** set_find *******************/
/* see set.h for description */
void* 
set_find(set_t* set, const char* key)
{
    if (set == NULL || key == NULL) {       // return NULL if any parameter returns NULL
        return NULL;
    }
    for (setnode_t* nodep = set->head; nodep != NULL; nodep = nodep->next) {
        if (strcmp(nodep->key, key) == 0) { // continue until key match or the end
            return nodep->item;
        }
    }       
    return NULL;
}

/**************** set_print *******************/
/* see set.h for description */
void
set_print(set_t* set, FILE* fp, void (*itemprint)(FILE* fp, const char* key, void* item)) 
{
    if (fp != NULL) {
        if (set != NULL) {
            for (setnode_t* node = set->head; node != NULL; node = node->next) {
                // print this node
                if (itemprint != NULL) {                     // print the node's key
                    fputc('{', fp);
                    (*itemprint)(fp, node->key, node->item);
                    fputc('}', fp);
                    if (node->next != NULL) {               // put the comma for all but the last entry
                        fputc(',',fp);
                    }
                }
            }
            
        }
    }
}
/***************** set_iterate ****************/
/* see set.h for description */
void 
set_iterate(set_t* set, void* arg, void (*itemfunc)(void* arg, const char* key, void* item) )
{
    if (set != NULL && itemfunc != NULL) {      //do nothing if either parameter is NULL}
        for (setnode_t* nodep = set->head; nodep != NULL; nodep = nodep->next) {
            (*itemfunc)(arg, nodep->key, nodep->item);
        } 
    }
}

/**************** set_delete *****************/
/* see set.h for description */
void 
set_delete(set_t* set, void (*itemdelete)(void* item) )
{
    if (set != NULL) {
        for (setnode_t* nodep = set->head; nodep != NULL; ){
            if (itemdelete != NULL) {
                (*itemdelete)(nodep->item);
            }
            setnode_t* next = nodep->next;      // save for future accessing after nodep is freed
            free((void *) nodep->key);
            free(nodep);
            nodep = next;
        }
        free(set);
    }
}

