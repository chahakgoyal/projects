# Game

This subdirectory contains the files necessary to implement the `game` struct used by the server for the nuggets game. It includes several files:

* game.c
* game.h
* gametest.c
* grid.c
* grid.h
* gridtest.c
* player.c
* player.h
* Makefile

The `game` struct utilizes two other structs, `player` and `grid`, to execute the nuggets game. 
* The `player` contains information about the purse of a player, the visible grid for that player, the player's current x and y coordinates, whether that player is active or not and the  original char value beneath its current location. See `player.h` for details.
* The `grid` is a data structure designed to store information about a map, as well as delete a grid, return visibility and print the grid as a string. See `grid.h` for details.

The `game` module itself keeps track of the combination of these two structs. It retains information about each player's location, number of coins, activation status, as well as updates the game with every change.

## Grid
The `grid` module is implemented in grid.c, which has functions defined in grid.h. A grid structure contains a 2-D array of characters, an integer number of columns and an integer number of rows. Testing is implemented in gridtest.c.

### Grid Functions 

The following functions are defined in grid.h:

```c
grid_t* grid_new(FILE* fp);
grid_t* grid_empty(int nr, int nc);
char grid_get(grid_t* grid, int x, int y);
void grid_set(grid_t* grid, int x, int y, char newChar);
bool grid_isVisible(grid_t* full, int currx, int curry, int otherx, int othery);
void grid_visible(grid_t* full, int currx, int curry, grid_t* visible, char oldSpot);
int grid_nc(grid_t* grid);
int grid_nr(grid_t* grid);
bool grid_valid(grid_t* grid, int x, int y);
char* grid_getString(grid_t* grid);
void grid_delete(grid_t* grid);
void grid_print(grid_t* grid);
```

### Grid Testing 

The testing file gridtest.c takes one argument: a valid map file.
```
./gridtest anymap.txt
```
Grid test makes a grid, prints it out, sets characters, checks visibility, and then deletes the grid. 

## Player 
The `player`module is implemented in player.c, which has functions defined in player.h. A player structure contains an integer purse, a grid_t* visible, integers for the player's current x and y locations, a bool value for if the player is active, a character oldspot, an addr_t address and a char* name. 

## Player Functions 

The following functions are defined in player.h:

```c
player_t* player_new(int NC, int NR, int x, int y, grid_t* full, addr_t address, char* name);
char* player_getName(player_t* player);
addr_t player_getAddress(player_t* player);
bool player_isActive(player_t* player);
int player_purse(player_t* player);
void player_addToPurse(player_t* player, int value);
grid_t* player_visible(player_t* player);
void player_setPoint(player_t* player, int newx, int newy);
int player_currx(player_t* player);
int player_curry(player_t* player);
char player_getOldSpot(player_t* player);
void player_setOldSpot(player_t* player, char oldSpot);
void player_delete(player_t* player);
void player_quit(player_t* player);
```

## Game
The `game` module is implemented in game.c, which has functions defined in game.h. A game structure contains a full grid_t*, integers remaining gold, remaining gold piles, number of players and gold history, an array of player_t structs (all the player in the game), an addr_t address for the spectator and a boolean that says whether the game has a spectator or not. The game module also has a testing file, gametest.c.

### Game Functions 

The following functions are defined in game.h:

```c
game_t* game_new(FILE* fp, int totalGold, int numGoldPiles);
char game_getPlayerKey(game_t* game, addr_t address);
int game_gold(game_t* game);
char* game_grid(game_t* game);
char* game_playerGrid(game_t* game, char playerKey);
int game_randomGold(game_t* game);
void game_update(game_t* game, char playerKey, char action);
void game_newPlayer(game_t* game, char playerKey, addr_t address, char* name);
int game_playerPurse(game_t* game, char playerKey); 
bool game_playerActive(game_t* game, char playerKey);
bool game_spectator(game_t* game);
int game_numPlayers(game_t* game);
int game_nc(game_t* game);
int game_nr(game_t* game);
void game_delete(game_t* game);
addr_t game_getAddress(game_t* game, char playerKey);
char* game_getName(game_t* game, char playerKey);
void game_setSpectator(game_t* game, addr_t spectator);
bool game_isSpectator(game_t* game, addr_t address);
addr_t game_getSpectator(game_t* game);
player_t** game_getPlayers(game_t* game);
void game_deleteSpectator(game_t* game);
void game_deletePlayer(game_t* game, char playerKey);
int game_goldHistory(game_t* game);
```


### Game Testing

The testing file gametest.c conducts a round of testing for the game struct. Gametest takes three arguments: a FILE*, an integer total number of gold, and an integer number of gold piles. 

```
./gametest somemap.txt 40 5
```
The gametest creates a grid, prints the grid as a string, adds random amounts of gold, adds players, has them move, and then looks at their visibility grids. 


## Compiling
To compile,
```
make
```

To clean,
```
make clean
```
