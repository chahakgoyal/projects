/* 
 * game.h - header file for CS50 game module
 * 
 *
 * a-sparagus, May 2021
 */

#ifndef __game_H
#define __game_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "grid.h"
#include "player.h"
#include "../support/message.h"
#include "../support/set.h"

/**************** global types **************/
typedef struct game game_t;

/*************** functions ****************/

/************** game_new *****************/
/* Create and reurn a pointer to a game 
 *
 * Caller provides: 
 *  a FILE*, integer total gold and integer number of gold piles
 * We return:
 *  pointer to the new game; NULL if error.
 * We guarantee: 
 *  game is initialized
 * Caller is responsible for:
 *  later calling player_delete
 */
game_t* game_new(FILE* fp, int totalGold, int numGoldPiles);

/************* game_getPlayerKey **********/
/* given an address, returns key assocaited with that addr_t */
char game_getPlayerKey(game_t* game, addr_t address);

/************* game_gold *****************/
/* Return an integer remainingGold in game
 *
 * Caller provides:
 *  a valid game
 * We return:
 *  the integer remaining gold in the game
 */
int game_gold(game_t* game);

/************* game_grid ****************/
/* Return the game's grid as a string 
 *
 * Caller provides:
 *  a valid game
 * We return: 
 *  a string representing the game's grid
 * Caller is responsible for:
 *  later freeing the string 
 */
char* game_grid(game_t* game);

/*********** game_playerGrid **************/
/* Returns the grid (in string form) as visible to a player
 * Caller provides:
 *  pointer to a valid game
 *  a valid player key
 * We return:
 *  a string representation of the relevant grid
 * Caller is responsible for:
 *  later freeing the string
 */
char* game_playerGrid(game_t* game, char playerKey);

/************ game_randomGold ***************/
/* Return an integer for a random amount of gold in a gold pile
 *
 * Caller provides:
 *  a valid game
 * We return:
 *  an integer an amount that could reasonably be in one pile
 */
int game_randomGold(game_t* game);

/************ game_update *****************/
/* Update the game based on the action of a certain player
 *
 * Caller provides:
 *  a playerKey, an action and a valid game
 */
void game_update(game_t* game, char playerKey, char action);

/*********** game_newPlayer ************/
/* Adds a new player to the game 
 *
 * Caller provides:
 *  a playerKey and a valid game
 */
void game_newPlayer(game_t* game, char playerKey, addr_t address, char* name);

/********** game_playerPurse ***********/
/* Returns the players purse (int)
 *
 * Caller provides:
 *  a player key and a valid game
 * We return:
 *  integer amount of coins in the player's purse
 */
int game_playerPurse(game_t* game, char playerKey); 

/************* game_playerActive ***********/
/* Returns whether the player is active or not
 *
 * Caller provides:
 *  a player key and a valid game
 * We return:
 *  boolean indicating player's active status
 */
bool game_playerActive(game_t* game, char playerKey);

/************ game_spectator *************/
/* return true if there is a spectator and false if not 
 *
 * Caller provides:
 *   a valid game
 * We return: 
 *  a boolean value true if there is a spectator false if not
 */
bool game_spectator(game_t* game);

/*************** game_numPlayers ************/
/* return the integer number of players in the game (active and inactive)
 *
 * Caller provides:
 *   a valid game
 * We return: 
 *  the number of players in the game
 */
int game_numPlayers(game_t* game);

/*************** game_nc *****************/
/* returns the number of columns in the game's grid
 *
 * Caller provides:
 *  a valid game 
 * We return:
 *  number of columns in game's grid
 */
int game_nc(game_t* game);

/************** game_nr ***************/
/* returns the number of rows in the game's grid
 *
 * Caller provides:
 *  a valid game
 * We return:
 *  number of rows in the game's grid 
 */
int game_nr(game_t* game);

/************* game_delete *************/
/* free the memory allocated in creating the game
 *
 * Caller provides:
 *  a valid game
 * We guarantee:
 *  memory will be freed
 */
void game_delete(game_t* game);

/**************** game_getAddress ********/
/* get a players address 
 *
 * Caller provides: 
 *   a valid game and a char playerKey
 * we return:
 *   the addr_t associated with that playerKey in the game 
 */
addr_t game_getAddress(game_t* game, char playerKey);

/***************** game_getName ********/
/* get players name 
 *
 * Caller provides: 
 *    a valid game and a char playerkey
 * We return:
 *    the player's name as a char*
 */
char* game_getName(game_t* game, char playerKey);

/***************** game_setSpectator *******/
/* set the game's spectator 
 *
 * Caller provides: 
 *   a valid game and the spectator's addr_t 
 *
 * We guarantee:
 *   this addr_t will be associated with the game's spectator struct
 */
void game_setSpectator(game_t* game, addr_t spectator);

/****************** game_isSpectator *********/
/* check if an address is the spectators address 
 *
 * Caller provides:
 *    a valid address and a valid game
 *
 * We return: 
 *    true if this addr_t is associated with the spectator, and false otherwise 
 */
bool game_isSpectator(game_t* game, addr_t address);

/****************** game_getSpectator ******/
/* get the spectator's address
 *
 * Caller provides:
 *    a valid game
 * We return:
 *    the spectator's addr_t
 */
addr_t game_getSpectator(game_t* game);

/***************** game_getPlayers *********/
/* get the game's array of player_t's
 *
 * Caller provides: 
 *    a valid game
 * We return: 
 *    the game's array of players (player_t structs)
 */
player_t** game_getPlayers(game_t* game);

/********** game_deleteSpectator *********/
/* delete the game's spectator 
 *
 * Caller provides:
 *   a valid game
 * We guarantee:
 *   the game's currSpectator is set to false
 */
void game_deleteSpectator(game_t* game);

/********** game_deletePlayer *********/
/* delete a player from the game
 *
 * Caller provides:
 *      a valid game and a char playerKey
 * We guarantee:
 *      the player will be inactivated using player_quit
 *      the player will be removed from the grid 
 */
void game_deletePlayer(game_t* game, char playerKey);

/*************** game_goldHistory ********/
/* return int of gold just obtained 
 *
 * Caller provides:
 *    a valid game
 * We return:
 *    the integer amount of gold just obtained
 */
int game_goldHistory(game_t* game);

#endif // __game_H

