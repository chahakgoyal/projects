
/*
 * game.c - Implements methods, and the 'game' data structure as outlined in game.h
 *
 * a-sparagus, May 2021
 */

 #include <stdio.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include "game.h"
 #include "player.h"
 #include "grid.h"
 #include <time.h>
 #include "../support/mem.h"
 #include "../support/set.h"
 #include "../support/message.h"


/********************* global_types ****************************/
typedef struct game
{
    grid_t* full;
    int remainingGold;
    int remainingGoldPiles;
    int numPlayers;
    bool currSpectator;
    addr_t spectatorAddress;
    int goldHistory;
    player_t** playerArray;
} game_t;

/********************** local functions *************************/
static bool updateHelper(game_t* game, player_t* currPlayer, int updatedx, int updatedy, char playerKey);
static void locationUpdate(char action, int* x, int* y);
static void updateVisibleGrids(game_t* game);

/********************* game_new ***************************/
/* allocate memory for, and initialize an new game struct with the given parameters */
game_t*
game_new(FILE* fp, int totalGold, int numGoldPiles)
{

    srand ( time(NULL) );
    game_t* game = mem_malloc(sizeof(game_t)); 
    if (game != NULL) {

        grid_t* full = grid_new(fp);
        game->full = full;
        game->remainingGold = totalGold;
        game->remainingGoldPiles = numGoldPiles;
        game->numPlayers = 0;
        game->goldHistory = 0;
        game->currSpectator = false;
        game->playerArray = mem_malloc(26 * sizeof(player_t**));

        // for each goldpile find a valid random spot to put it 
        for (int i = 0; i <numGoldPiles; i++) {       
            int randx = rand() % (grid_nc(full)-1);
            int randy = rand() % (grid_nr(full)-1);

            while (grid_get(full, randx, randy) != '.'){
                randx = rand() % (grid_nc(full)-1);
                randy = rand() % (grid_nr(full)-1);
            }
            grid_set(full, randx, randy, '*');
        }
    } else {
        fprintf(stderr, "Error allocating memory for game\n");
        return NULL;
    }
    return game;

}

/****************** game_getPlayerKey *************/
/* return the player key that is associated with this address */
char
game_getPlayerKey(game_t* game, addr_t address)
{
    char c = 'A';
    // iterate throuh the array 
    for (int i = 0; i < game->numPlayers; i++) {
      if (player_isActive(game->playerArray[i])) {      // check that player is active
        if (message_eqAddr(address, player_getAddress(game->playerArray[i]))) { // if this player has the same address 
            return (c + i);     // return its playerkey ('A' plus it's index)
        }
      }
    }
    return c;
}

/******************* game_getSpectator *************/
/* get the address of the game's spectator */
addr_t 
game_getSpectator(game_t* game)
{
    return game->spectatorAddress;
}

/********************* game_getPlayers ***********/
/* get the array of the game's players */
player_t**
game_getPlayers(game_t* game)
{
    return game->playerArray;
}

/******************** game_getAddress ****************/
/* given a playerkey, get an address */
addr_t
game_getAddress(game_t* game, char playerKey)
{

    int playerNumber = playerKey - 'A';
    // get the player 
    player_t* player = game->playerArray[playerNumber];
    return player_getAddress(player);

}

/******************** game_getName **************/
char*
game_getName(game_t* game, char playerKey)
{
    int playerNumber = playerKey - 'A';
    // get the player
    player_t* player = game->playerArray[playerNumber];
    return player_getName(player);
}

/******************** game_gold *********************/
/* returns the remaining gold in the game */
int
game_gold(game_t* game) {
    return game->remainingGold;
}

/******************** game_grid *******************/
/* returns the full grid of the game in string form */
char*
game_grid(game_t* game)
{
    if (game->full != NULL) {
        char* gridString = grid_getString(game->full);
        return gridString;
    } else {
        return NULL;
    }
}

/******************** game_playerGrid ***************/
/* return a player's visible grid as a string */
char*
game_playerGrid(game_t* game, char playerKey)
{
  if (game != NULL) {
    int playerNumber = playerKey - 'A';         // find the player's index in the array 
    player_t* currPlayer = game->playerArray[playerNumber];     // get the player out of the array 
    if (player_isActive(currPlayer)) {
      return grid_getString(player_visible(currPlayer));        // return their visible string 
    }
  }
  return NULL;
}

/******************* game_randomGold ***************/
/* return an appropriate random integer number of gold for a given pile */
int
game_randomGold(game_t* game)
{
    srand ( (time(NULL) ));
    // if this is the last pile return all the gold
    if (game->remainingGoldPiles == 1) {
        return (game->remainingGold);
    } else {
        // calculate a random amount of gold
        int proportional = (game->remainingGold) / (game->remainingGoldPiles);
        int variation = (rand() % proportional) - (proportional / 2);
        return proportional + variation;
    }
}

/****************** game_update ***************/
/* updates game according to a player and their action*/
void
game_update(game_t* game, char playerKey, char action)
{
    // use the playerKey to find playerstruct in the set of players
    // make a const char*
    int playerNumber = playerKey - 'A';
    player_t* currPlayer = game->playerArray[playerNumber];

    // get current x and y values for the player
    int currx = player_currx(currPlayer);
    int curry = player_curry(currPlayer);


    // change position values based on action

    // if action is a lower case letter
    if ((int)action > 96) {
      // carry out one-step actions
      locationUpdate(action, &currx, &curry);
      updateHelper(game, currPlayer, currx, curry, playerKey);
    } else {
      // Capitalised actions (repeat the action until possible)
      locationUpdate(action, &currx, &curry);
      while (updateHelper(game, currPlayer, currx, curry, playerKey)) {
        locationUpdate(action, &currx, &curry);
      }
    }
  }

static void
locationUpdate(char action, int* x, int* y)
{
  // convert character to lower case
  if ((int)action < 96) {
    action += 32;
  }
  switch (action) {
    // one step actions
    case 'k':
      (*y)--;
      break;
    case 'j':
      (*y)++;
      break;
    case 'l':
      (*x)++;
      break;
    case 'h':
      (*x)--;
      break;
    case 'y':
      (*y)--;
      (*x)--;
      break;
    case 'u':
      (*y)--;
      (*x)++;
      break;
    case 'b':
      (*y)++;
      (*x)--;
      break;
    case 'n':
      (*y)++;
      (*x)++;
      break;
  }
}

static bool
updateHelper(game_t* game, player_t* currPlayer, int updatedx, int updatedy, char playerKey)
{
  // check if the new position is valid
  if (grid_valid(game->full, updatedx, updatedy)){
      //keep track of old spot location
      int oldx = player_currx(currPlayer);
      int oldy = player_curry(currPlayer);
      char oldSpot = player_getOldSpot(currPlayer);
      // set new player to new spot
      player_setPoint(currPlayer, updatedx, updatedy);
      // reset grid to the character beneath the player's old location
      grid_set(game->full, oldx, oldy, oldSpot);
      //check if there is already a player at this new position
      char newSpot = grid_get(game->full, updatedx, updatedy);

      if (isalpha(newSpot)) {      // there is a playerkey here
          int otherPlayerNumber = newSpot - 'A';
          // get that player out of the array of players
          player_t* otherPlayer = game->playerArray[otherPlayerNumber];
          player_setPoint(otherPlayer, oldx, oldy);   // set them to our old spot
          grid_set(game->full, updatedx, updatedy, player_getOldSpot(otherPlayer));
          player_setOldSpot(otherPlayer, oldSpot);
          oldSpot = newSpot;
          //update the grid to display this player's playerkey
          grid_set(game->full, oldx, oldy, newSpot);
      }
      // get random gold amount if there is gold at the new position
      else if (newSpot == '*') {
          int gold = game_randomGold(game);
          // give the player that gold
          player_addToPurse(currPlayer, gold);
          printf("%d was added\n", gold);
          // subtract from the game
          game->remainingGold = game->remainingGold - gold;
          game->remainingGoldPiles = game->remainingGoldPiles - 1;
          game->goldHistory = gold;
          // change the grid value to a '.' to indicate that the gold has been collected by player
          grid_set(game->full, updatedx, updatedy, '.');
      }
      // get the player's visible grid and update it based on new location
      grid_t* visible = player_visible(currPlayer);
      grid_visible(game->full, updatedx, updatedy, visible, oldSpot);
      // update player's spot value
      oldSpot = grid_get(game->full,updatedx, updatedy);
      player_setOldSpot(currPlayer, oldSpot);
      // update grid to account for player's new position
      grid_set(game->full, updatedx, updatedy, playerKey);

      // now we need to iterate through the set of players and update their visible grids
      updateVisibleGrids(game);
    //  set_iterate(gamei->players, game, (&iterateHelp));
      return true;
  }
 
  else {
    return false;
  }
}

/***************** game_goldHistory **************/
/* return the amount of gold just obtained  in the game */
int
game_goldHistory(game_t* game) {
    return game->goldHistory;
}

/****************** game_newPlayer ****************/
/* create a new player and add them to the game */
void
game_newPlayer(game_t* game, char playerKey, addr_t address, char* name)
{
    int nc = grid_nc(game->full);
    int nr = grid_nr(game->full);
    // get a valid '.' point in the grid
    int randx = rand() % (nc - 1);
    int randy = rand() % (nr - 1);
    while (grid_get(game->full, randx, randy) != '.'){
        randx = rand() % (nc - 1);
        randy = rand() % (nr - 1);
    }
    // create a new player struct and insert it into the set
    player_t* newPlayer = player_new(nc, nr, randx, randy, game->full, address, name);

//    set_insert(game->players, playerKeyConst, newPlayer);
    game->playerArray[game->numPlayers] = newPlayer;
    // update numPlayers and add playerkey to the full game grid
    game->numPlayers = game->numPlayers + 1;
    grid_set(game->full, randx, randy, playerKey);
    updateVisibleGrids(game);

}

/**************** game_playerPurse ****************/
/* return the player's purse */
int
game_playerPurse(game_t* game, char playerKey) {
    int playerNumber = playerKey - 'A';

    player_t* player = game->playerArray[playerNumber];
    return player_purse(player);
}

/***************** game_playerActive *********/
/* return true if a player is active and false if not*/
bool
game_playerActive(game_t* game, char playerKey)
{
  return player_isActive(game->playerArray[playerKey - 'A']);
}

/****************** game_spectator ******************/
/* return true if there is a spectator and false if there is not */
bool
game_spectator(game_t* game) {
    return game->currSpectator;
}

/******************* game_numPlayers ****************/
/* return the number of players in the game */
int
game_numPlayers(game_t* game) {
    return game->numPlayers;
}

/******************* game_nc ****************/
/* return the number of columns in the game's grid */
int
game_nc(game_t* game) {
    return grid_nc(game->full);
}

/****************** game_nr ***************/
/* return the number of rows in the game's grid */
int
game_nr(game_t* game) {
    return grid_nr(game->full);
}

/****************** game_setSpectator************/
/* add a spectator addr_t to a game*/
void
game_setSpectator(game_t* game, addr_t spectator) {
    game->currSpectator = true;
    game->spectatorAddress = spectator;
}

/****************** game_isSpectator ************/
/* check if a given address is the spectator */
bool
game_isSpectator(game_t* game, addr_t address) {
  if (game != NULL) {
    if (game_spectator(game)) {
      return message_eqAddr(address, game->spectatorAddress);
    }
  }
  return false;
}

/***************** game_delete **************/
/* free space allocated in the creation of the game */
void
game_delete(game_t* game)
{
    grid_delete(game->full);
    for (int i = 0; i < game->numPlayers; i++) {
        player_delete(game->playerArray[i]);
    }
    free(game->playerArray);
    game->numPlayers = 0;
    free(game);
}

/***************** game_deleteSpectator *************/
/* mark that there is no current spectator */
void
game_deleteSpectator(game_t* game)
{
  game->currSpectator = false;
}

/**************** game_deletePlayer **************/
/* delete a player from a game */
void
game_deletePlayer(game_t* game, char playerKey)
{
  int playerNumber = playerKey - 'A';
  player_t* player = game->playerArray[playerNumber];
  grid_set(game->full, player_currx(player), player_curry(player), player_getOldSpot(player));
  player_quit(player);
  updateVisibleGrids(game);
}

/*************** updateVisibleGrids ***********/
/* for each player, update their visible grid */
static void
updateVisibleGrids(game_t* game)
{
  for (int i = 0; i < game->numPlayers; i++) {
    player_t* player = game->playerArray[i];
    if (player_isActive(player)) {
      grid_t* visible = player_visible(player);
      grid_visible(game->full,player_currx(player), player_curry(player), visible, player_getOldSpot(player));
    }
  }
}
