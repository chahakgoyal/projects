/*
 * player.h - header file for CS50 player module
 *
 * A *player* contains information about the purse of a player, the visible grid for that player,
 * the player's current x and y coordinates, whether that player is active or not and the  original char value
 * beneath its current location
 *
 * a-sparagus, May 2021
 */

#ifndef __player_H
#define __player_H

#include <stdio.h>
#include <stdbool.h>
#include "../support/message.h"
#include "grid.h"

/**************** global types ****************/
typedef struct player player_t;

/**************** functions ****************/

/**************** player_new ****************/
/* Create and return a pointer to a player struct.
 *
 * Caller provides:
 *   the number of rows and columns in the game's grid (must be > 0).
 *   the (x, y) location for the player
 *   the full grid representing the game
 * We return:
 *   pointer to the new player; return NULL if error.
 * We guarantee:
 *   player is initialized.
 * Caller is responsible for:
 *   later calling player_delete.
 */
player_t* player_new(int NC, int NR, int x, int y, grid_t* full, addr_t address, char* name);

/****************** player_getName **************/
/* Return the players name */
char* player_getName(player_t* player);

/******************* player_getAddress ***********/
/* return the players address */
addr_t player_getAddress(player_t* player);

/******************* player_isActive *************/
/* return boolean indicating whether a player is active or not */
bool player_isActive(player_t* player);

/****************** player_purse ******************/
/* Return the amount of gold collected by the player
 *
 * Caller provides:
 *    the pointer to the player struct (must be non-NULL)
 * We return:
 *    the value of the purse; return -1 if error.
 */
 int player_purse(player_t* player);

/****************** player_addToPurse *****************/
/* Increment the purse amount by the inputted value
 *
 * Caller provides:
 *   the pointer to the player struct (must be non-NULL)
 *   the amount by which to increase the total amount in the player's gold purse
*/
void player_addToPurse(player_t* player, int value);

/****************** player_visible *********************/ 
/* returns the grid that is visible to a player from its current position
 *
 * Caller provides:
 *    the pointer to the player struct (must be non-NULL)
 * We return:
 *    the grid structure that player can see
*/
grid_t* player_visible(player_t* player);

/******************** player_setPoint *******************/
/* change player's location to account for its actions
 *
 * Caller provides:
 *   the pointer to the player struct (must be non-NULL)
 *   the new (x, y) location for the player
*/
void player_setPoint(player_t* player, int newx, int newy);

/******************** player_currx **********************/
/* returns the current x coordinate of the player
 *
 * Caller provides:
 *    the pointer to the player struct (must be non-NULL)
 * We return:
 *    the int value of the current x coordinate; return -1 if error.
*/
int player_currx(player_t* player);

/******************** player_curry **********************/
/* returns the current y coordinate of the player
 *
 * Caller provides:
 *    the pointer to the player struct (must be non-NULL)
 * We return:
 *    the int value of the current y coordinate; return -1 if error.
*/
int player_curry(player_t* player);

/******************** player_getOldSpot **********************/
/* returns the character value beneath the location of the player
 *
 * Caller provides:
 *    the pointer to the player struct (must be non-NULL)
 * We return:
 *    the char value beneath the location of the player; return '!' if error.
*/
char player_getOldSpot(player_t* player);

/******************** player_setOldSpot **********************/
/* sets the character value stored in the player struct
 *
 * Caller provides:
 *    the pointer to the player struct (must be non-NULL)
 *    the char oldSpot to indicate  character value below the location of the player
*/
void player_setOldSpot(player_t* player, char oldSpot);

/******************** player_delete **********************/
/* frees the memory allocated via malloc's for the player struct
 *
 * Caller provides:
 *    the pointer to the player struct (must be non-NULL)
*/
void player_delete(player_t* player);

/********************* player_quit ***********************/
/* sets a player's active indicator to false
 *
 * Caller provides:
 *    the pointer to the player struct (must be non-NULL)
*/
void player_quit(player_t* player);

#endif // __player_H
