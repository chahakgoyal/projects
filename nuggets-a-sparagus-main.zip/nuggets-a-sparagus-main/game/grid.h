/*grid.h - header file for nuggets 'grid' module
 *
 * grid module - a data structure to store maps
 *
 * a-sparagus, May 2021
 */

#ifndef __grid_H
#define __grid_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include "grid.h"

/************ global types ************/
typedef struct grid grid_t; 

/************* functions *****************/

/*********** grid_new **************/
/* Create and return a pointer to a grid struct.
 *
 * Caller provides:
 *  a FILE* (of lines nr and line length nc)
 * We return:
 *  a pointer to a new grid; NULL if there was any problem mallocing grid, map or map rows
 * We guarantee: 
 *  the grid now stores the file's characters as a char**
 *  nr is the number of lines
 *  nc is the length of the lines
 * Caller is responsible for:
 *  later calling grid_delete
 */
grid_t* grid_new(FILE* fp);

/*********** grid_empty ************/
/* Create and return a pointer to a grid struct of requested size but without any characters
 *
 * Caller provides:
 *  an integer num rows and an integer num columns
 * We return:
 *  a pointer to an empty grid of requested size; NULL if there was any problem mallocing
 * We guarantee: 
 *  the grid is empty and has nr rows and nc columns
 * Caller is responsible for:
 *  later calling grid_delete
 */
grid_t* grid_empty(int nr, int nc);

/************ grid_get ************/
/* Return the character at a given locaton 
 *
 * Caller provides:
 *  a valid grid and two integers for the row number and column number
 * We return:
 *  the character at that grid point
 */
char grid_get(grid_t* grid, int x, int y);

/************ grid_set ************/
/* Set the given location to given character
 * 
 * Caller provides:
 *  a valid grid, two integers for row number and column number and a new character
 */
void grid_set(grid_t* grid, int x, int y, char newChar);

/************grid_isVisible ********/
/* Return bool value based on visibility of location (otherx, othery) from (currx, curry)
 *
 * Caller provides:
 *  a valid grid, a current location and an 'other' point
 * We return:
 *  true if the point is visible and false if the point is not visible 
 */
bool grid_isVisible(grid_t* full, int currx, int curry, int otherx, int othery);

/************ grid_visible ********/
/* Fill in current visibility for given grid_t* visible
 *
 * Caller provides:
 *  two valid grids full and visible, a current location (currx, curry) and the character at the player's old spot
 * We guarantee:
 *  visible graph will contain old visited spaces and the real information visible now
 */
void grid_visible(grid_t* full, int currx, int curry, grid_t* visible, char oldSpot);

/*********** grid_nc ************/
/* Return an integer number of columns in the grid 
 *
 * Caller provides:
 *  a valid grid
 * We return:
 *  an integer number of columns
 */
int grid_nc(grid_t* grid);

/*********** grid_nr ***********/
/* Return an integer number of rows in the grid
 *
 * Caller provides:
 *  a valid grid_t*
 * We return:
 *  an integer number of rows
 */
int grid_nr(grid_t* grid);

/*********** grid_valid *********/
/* Return a bool value based on if the character at given point is a '.' '*' or '#'
 *
 * Caller provides:
 *  a valid grid_t* and a location (x, y)
 * We return:
 *  true if the character at that point is a '.' '*' or '#' and false otherwise
 */
bool grid_valid(grid_t* grid, int x, int y);

/********** grid_getString ********/
/* Create and return a char* representing all the characters in the grid's char ** map
 *
 * Caller provides:
 *  a valid grid_t* 
 * We return:
 *  a char* or NULL if there is a problem mallocing memory 
 * We guarantee: 
 *  char* is made up of all the characters in the grid's char ** map
 * Caller is responsible for:
 *  later calling free() on the returned char*
 */
char* grid_getString(grid_t* grid);

/*********** grid_delete ***********/
/* Free the space allocated in grid_new or grid_empty 
 * 
 * Caller provides:
 *  a valid grid_t*
 * We guarantee:
 *  memory will be freed
 */
void grid_delete(grid_t* grid);

/*********** grid_print *********/
/* prints the grid to stdout - used for testing 
 *
 * Caller provides:
 *   a valid grid
 */
void grid_print(grid_t* grid);
  
#endif // __grid_H
