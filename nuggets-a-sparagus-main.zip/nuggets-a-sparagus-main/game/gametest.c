/* 
 * testfile for game.c
 *
 * a-sparagus, May 2021
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "grid.h"
#include "player.h"
#include "game.h"
#include "../support/message.h"

int
main(int argc, char* argv[])
{ 
    // argv[1] is FILE* fp
    // argv[2] is int totalGold
    // argv[3] is int numGoldPiles

    char* filename = argv[1];
    FILE* fp = fopen(filename, "r");

    int totalGold = atoi(argv[2]);
    int numGoldPiles = atoi(argv[3]);

    addr_t addra;
    addr_t addrb;
    char* namea = (char*)malloc(8);
    char* nameb = (char*)malloc(8);
    strcpy(namea, "playerA");
    strcpy(nameb,  "playerB");

    game_t* game1;
    game1 = game_new(fp, totalGold, numGoldPiles);

    fclose(fp);

    // test game_gold
    int remainingGold = game_gold(game1);
    printf("remaining gold: %d\n", remainingGold);

    // test game_grid
    char* gridString = game_grid(game1);
    printf("grid as a string:\n%s\n", gridString);
    free(gridString);

    // test game_randomGold
    int randomGold;
    randomGold = game_randomGold(game1);
    printf("random gold: %d\n", randomGold);

    // create new player and print grid
    game_newPlayer(game1, 'A', addra, namea);

    gridString = game_grid(game1);
    printf("grid as a string:\n%s\n", gridString);
    free(gridString);

    // new player moves up
    game_update(game1, 'A', 'u');
    printf("player moves up\n");

    // print game 
    gridString = game_grid(game1);
    printf("grid as a string:\n%s\n", gridString);
    free(gridString);

    // test player purse
    int purse = game_playerPurse(game1, 'A');
    printf("purse is: %d\n", purse);

    // test game_numPlayers
    int numPlayers = game_numPlayers(game1);
    printf("number of players: %d\n", numPlayers);

    // test game_spectator
    bool isSpec = game_spectator(game1);
    printf("spec value: %d\n", isSpec);

    // test game_nc and game_nr
    int nc = game_nc(game1);
    int nr = game_nr(game1);
    printf("nc is %d, nr is %d\n", nc, nr);

    // add another player 
    game_newPlayer(game1, 'B', addrb, nameb);
    gridString = game_grid(game1);
    printf("\n%s\n", gridString);
    free(gridString);

    // everyone attempts to move down
    game_update(game1, 'A', 'j');
    game_update(game1, 'B', 'j');

    // reprint the grid
    gridString = game_grid(game1);
    printf("\n%s\n", gridString);
    free(gridString);

    // print scores 
    int purseA = game_playerPurse(game1, 'A');
    int purseB = game_playerPurse(game1, 'B');
    printf("A: %d, B: %d", purseA, purseB);

    gridString = game_playerGrid(game1, 'A');
    printf("A's visible grid\n%s\n", gridString);
    free(gridString);

    gridString = game_playerGrid(game1, 'B');
    printf("B's visible grid\n%s\n", gridString);
    free(gridString);

  
    game_delete(game1); 
    return 0;

    

}
