/*
 * file to test grid data structure
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include "grid.h"

int
main(int argc, char* argv[])
{ 
    char* filename = argv[1];
    FILE* fp = fopen(filename, "r");
    grid_t* grid = grid_new(fp);
   
    // print out the columnss and rows
    int i = grid_nc(grid);
    printf("number of columns %d\n", i);
    int j = grid_nr(grid);
    printf("number of rows %d\n", j);

    // create an empty grid
    int nr = grid_nr(grid);
    int nc = grid_nc(grid);
    grid_t* empty = grid_empty(nr, nc);

    fclose(fp);
    
    // print out the columns and rows
    int k = grid_nc(empty);
    int l = grid_nr(empty);
    printf("number of columns: %d, number of rows: %d\n", k, l);

    // print out the given grid
    printf("printing out given grid with grid_print\n");
 
    grid_print(grid);

    // get a character
    char c = grid_get(grid, 5, 3);
    printf("%c\n", c);

    // set a character
    char e = 'e';
    
    grid_set(grid, 5, 3, e);
    printf("%c\n", grid_get(grid, 5, 3));

    printf("printing using grid_print\n");
    grid_print(grid);

    // check validity 
    bool valid = grid_valid(grid, 5, 3);
    printf("%d\n", valid);

    valid = grid_valid(grid, 3, 4);
    printf("%d\n", valid);

    // get the grid in string format
    char* gridString = grid_getString(grid);
    printf("\nprinting the string\n%s", gridString);
    free(gridString);

    // test visibility
    printf("visibility check:\n");
    grid_visible(grid, 5, 3, empty, e);
    grid_print(grid);
    printf("visible from E: \n");
    grid_print(empty);
  
    // delete
    grid_delete(grid);
    grid_delete(empty); 

    // delete an empty grid
    grid_t* empty2;
    empty2 = grid_empty(10,10);
    grid_delete(empty2);


}
