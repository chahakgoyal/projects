/*
 * player.c - Implements methods, and the 'player' data structure as outlined in player.h
 *
 * Itish Goel, May 2021
 */

 #include <stdio.h>
 #include <stdlib.h>
 #include "../support/message.h"
 #include "grid.h"

/********************* global_types ****************************/
typedef struct player {
  int purse;
  grid_t* visible;
  int currx;
  int curry;
  bool active;
  char oldSpot;
  addr_t address;
  char* name;
} player_t;

/********************* player_new ***************************/
/* allocate memory for, and initialize an new player struct with the givn parameters */
player_t*
player_new(int nc, int nr, int x, int y, grid_t* full, addr_t address, char* name)
{
  player_t* player = malloc(sizeof(player_t));      
  player->purse = 0;
  player->active = true;
  player->currx = x;
  player->curry = y;
  char oldSpot = grid_get(full, x, y);
  player->oldSpot = oldSpot;
  grid_t* grid = grid_empty(nr, nc);
  grid_visible(full, x, y, grid, oldSpot);
  player->visible = grid;
  player->address = address;
  player->name = name;

  return player;
}

/******************** player_getName ********************/
char*
player_getName(player_t* player){
    return player->name;
}

/********************* player_getAddress ***************/
addr_t
player_getAddress(player_t* player) {
    return player->address;
}

/********************* player_purse ****************************/
/* return the amount of gold that a player has (purse) */
int
player_purse(player_t* player)
{
  return player->purse;
}

/********************* player_isActive **************************/
bool
player_isActive(player_t* player)
{
  return player->active;
}
/********************** player_addToPurse ************************/
/* Increments the amount of gold that a player has */
void
player_addToPurse(player_t* player, int value)
{
  player->purse = player->purse + value;
}

/************************ player_visible *************************/
/* returns the grid_t* which contains the points in the map which given player has ever been able to see */
grid_t*
player_visible(player_t* player)
{
  return player->visible;
}

/************************** player_setPoint ************************/
/* update the current location of the player */
void
player_setPoint(player_t* player, int newx, int newy)
{
  player->currx = newx;
  player->curry = newy;
}

/*************************** player_currx ***************************/
/* returns the current x coordinate of the player */
int
player_currx(player_t* player)
{
  return player->currx;
}

/*************************** player_curry *****************************/
/* returns the current y coordinate of the player */
int
player_curry(player_t* player)
{
  return player->curry;
}

/**************************** player_getOldSpot ***********************/
/* return the character beneath the player's previous location */
char
player_getOldSpot(player_t* player)
{
  return player->oldSpot;
}

/**************************** player_setOldSpot ************************/
/* set given char to the value of player's old spot */
void
player_setOldSpot(player_t* player, char oldSpot)
{
  player->oldSpot = oldSpot;
}

/**************************** player_quit **************************/
/* sets a player's active indicator to false */
void
player_quit(player_t* player)
{
  player->active = false;
}

/*************************** player_delete *************************/
/* frees the memory allocated via malloc's for the player struct */
void
player_delete(player_t* player)
{
  if (player != NULL) {
    if (player->visible != NULL) {
      grid_delete(player->visible);
    }
    free(player->name);
    free(player);
  }
}
