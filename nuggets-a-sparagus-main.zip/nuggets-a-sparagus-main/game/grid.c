/*
 * grid - a Nuggets Game support module
 *
 * Describes the grid data structure.
 * Individual clients and the overall game will store
 * map information within this structure.
 *
 * Maps are provided as .txt files composed of space characters, '.', '#', '-', '+', and possibly more.
 * These characters build a visual space.
 * The grid data structure does not seek to define or understand, only to hold
 * information for display.
 *
 * a-sparagus, May 2021
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <ctype.h>
#include "../support/file.h"
#include "../support/mem.h"


/*****************  global types ***************/
typedef struct grid {
    char** map;         // 2d array of characters
    int nc;             // number of columns
    int nr;             // number of rows 
} grid_t;

/***************** functions *******************/

/***************** grid_new *******************/
/* allocate memory for, and initialize a new grid struct with given parameters */
grid_t*
grid_new(FILE* fp) {

    grid_t* grid = mem_malloc(sizeof(grid_t));
    if (grid == NULL) {         // check malloc
        return NULL;
    }

    // find number of columns by length of first line
    char* line = file_readLine(fp);
    int nc = strlen(line);
    grid->nc = nc;      
    free(line);

    // find number of rows using number of lines in file
    int nr = file_numLines(fp);
    grid->nr = nr;
    grid->map = mem_malloc(nr * sizeof(char**)); // allocate memory for each row
    char** map = grid->map;
    if (map == NULL) {      // check malloc
        return NULL;
    }

    // allocate memory for each row's char*
    for ( int i = 0; i < nr; i++ ){
        map[i] = mem_malloc(nc + 1);
        if (map[i] == NULL) {   // check malloc
            return NULL;
        }
    }

    // go through file line by line and add each character to the char** map
    for ( int r = 0; r < nr; r++ ) {        // for each row
        line = file_readLine(fp);           // load in the next line

        // for each character in the line add it to the char** map
        for ( int k = 0; k < nc; k++) {
            map[r][k] = line[k];
        }
        map[r][nc] = '\0';     // must be null-terminated 
        free(line);
    }
    grid->map = map;

    return grid;
}

/******************* grid_empty *****************/
/* create an empty grid of given size nr x nc */
grid_t*
grid_empty(int nr, int nc) {

    // malloc grid_t* instance
    grid_t* grid = (grid_t*)malloc(sizeof(grid_t));

    if (grid == NULL) {     // check malloc   
        return NULL;
    }

    // initialize 2D array
    char** map = mem_malloc(nr * sizeof(char**));    // malloc each row
        if (map == NULL) {      // check malloc
            return NULL;
    }

    // allocate memory for each row's char*
    for ( int i=0; i < nr; i++ ) {
        map[i] = mem_malloc(nc + 1);
        if (map[i] == NULL) { // check malloc
            return NULL;
        }
    }

    // go through the file and add an ' ' for each gridpoint in the 2d array
    for (int r = 0; r < nr; r++) {
        for (int k = 0; k < nc; k++) {
            map[r][k] = ' ';
     }
      map[r][nc] = '\0';        // must be null terminated
    }

    grid->nr = nr;
    grid->nc = nc;
    grid->map = map;

    return grid;

}
/****************** grid_get ****************/
/* returns the character at a given location */
char
grid_get(grid_t* grid, int x, int y) {
    char c = grid->map[y][x];
    return c;
}

/***************** grid_set ***************/
/* set a given location to a given new character */
void grid_set(grid_t* grid, int x, int y, char newChar) {
    grid->map[y][x] = newChar;
}

/****************** grid_isVisible *************/
/* returns if a given location (otherx, othery) is visible from (currx, curry) */
bool
grid_isVisible(grid_t* full, int currx, int curry, int otherx, int othery){

    char exactC = ' ';      // the character found at an exact intersection
    char lowC = ' ';        // the character found above a place of intersection (lower y value)
    char highC = ' ';       // the character found below a place of intersection (higher y value)
    double slope = 0;       // slope between current point and possible visible point
    double y1 = 0;          // intersection y value
    double x1 = 0;          // intersection x value
    char c = ' ';      // character found
    int diffx = otherx - currx;     // difference between x values
    int diffy = othery - curry;     // difference between y values 

    slope = ((double)diffy / (double)diffx); // slope is difference in y divided by difference in x

    // if the points are vertically aligned
    if (diffx == 0) {
        if (diffy > 0) {        // if the other point is below the current location 
            for (int i = othery -1; i > curry; i--) {       // for each location inbetween 
                c = grid_get(full, currx, i);
                if ((c == '.' || isalpha(c) || (c == '*'))) {       // continue if it doesnt block visibility 
                    continue;
                } else {
                    return false;       // invalid if it blocks visibility: return false
                }
            }
            return true;
        } else if (diffy < 0) {     // if the other point is above the current location 
            for (int i = othery + 1; i < curry; i++) {      // for each location inbetween 
                c = grid_get(full, currx, i);
                if ((c == '.' || isalpha(c) || (c == '*'))) {        // continue if it doesnt block visibility 
                    continue;
                } else {
                    return false;       // invalid if it blocks visibility: return false
                }
            }
            return true;
        }
        return true;

    // if the other  point is to the rightof the current point 
    } else if (diffx > 0) {
      // check each column
      for (int i = currx + 1; i < otherx; i++) {
          y1 = (curry - slope*(currx - i));       // point slope calculation of the second y value
          // check if y1 is an integer
          int y1Low = floor(y1);
          int y1High = ceil(y1);
          if (y1Low == y1 && y1High == y1) {                  // this point is aligned with curr pos and other pos
              exactC = grid_get(full, i, y1);                 // get this gridpoint
              if ((exactC == '.') || (isalpha(exactC)) || (exactC == '*')) {    // continue if we can 'see through it'
                  continue;
              } else {  
                  return false;     // if it is not visible we know it blocks vision: return false
              }
          } else {
              // get the values of the points directly above/below the point of intersection
              lowC = grid_get(full, i, y1Low);
              highC = grid_get(full, i, y1High);
              // if the above character is blocking vision and the below character is blocking vision return false
              if ( ((lowC != '.') && (!isalpha(lowC)) && (lowC != '*')) && ((highC != '.') && (!isalpha(highC)) && (highC != '*'))) {
                  return false;
              } else {
                  continue;
              }
          }
      }
      // check each row when the point is below current point 
      if (diffy > 0) {
        for (int i = curry + 1; i < othery; i++) {
            x1 = currx + ((i - curry)/slope);           // calculation of the x coordinate of the intersection
            // check if x1 is an integer
            int x1Low = floor(x1);
            int x1High = ceil(x1);
            if (x1Low == y1 && x1High == x1) {                  // this point is exactly aligned with curr pos and other pos
                exactC = grid_get(full, x1, i);
                if ((exactC == '.') || (isalpha(exactC)) || (exactC == '*')) {  // allows for visibility
                    continue;
                } else {
                    return false;           // blocks visibility
                }
            } else {
                // get the values of the points directly to the left and right of the point of intersection
                lowC = grid_get(full, x1Low, i);
                highC = grid_get(full, x1High, i);
                // if the above character is blocking vision and the below character is blocking vision return false
                if ( ((lowC != '.') && (!isalpha(lowC)) && (lowC != '*')) && ((highC != '.') && (!isalpha(highC)) && (highC != '*'))) {
                    return false;
                } else {
                    continue;
                }
            }
        }
        //  check each row when point is above current point 
      } else {  
        for (int i = curry - 1; i > othery; i--) {          
            x1 = currx + ((i - curry)/slope);               // x coordinate of intersection
            // check if x1 is an integer
            int x1Low = floor(x1);
            int x1High = ceil(x1);
            if (x1Low == y1 && x1High == x1) {                  // this point is exactly aligned with curr pos and other pos
                exactC = grid_get(full, x1, i);
                if ((exactC == '.') || (isalpha(exactC)) || (exactC == '*')) {  
                    continue;
                } else {
                    return false;       // if it is not see through then it directly blocks visibility 
                }
            } else {
                lowC = grid_get(full, x1Low, i);
                highC = grid_get(full, x1High, i);
                // if the above character is blocking vision and the below character is blocking vision return false
                if ( ((lowC != '.') && (!isalpha(lowC)) && (lowC != '*')) && ((highC != '.') && (!isalpha(highC)) && (highC != '*'))) {
                    return false;
                } else {
                    continue;
                }
            }
        }
      }
      return true;
      // if the other point is to the left of the current point
    } else {
        // check the columns as we did for points to the right 
      for (int i = currx - 1; i > otherx; i--) {
        y1 = (curry - slope*(currx - i));       // point slope calculation of the second y value
        // check if y1 is an integer
        int y1Low = floor(y1);
        int y1High = ceil(y1);
        if (y1Low == y1 && y1High == y1) {                  // this point is exactly aligned with curr pos and other pos
            exactC = grid_get(full, i, y1);
            if ((exactC == '.') || (isalpha(exactC)) || (exactC == '*')) {
                continue;
            } else {
                return false;           // if not see through it directly blocks visibility 
            }
        } else {
            lowC = grid_get(full, i, y1Low);
            highC = grid_get(full, i, y1High);
            // if the above character is blocking vision and the below character is blocking vision return false
            if ( ((lowC != '.') && (!isalpha(lowC)) && (lowC != '*')) && ((highC != '.') && (!isalpha(highC)) && (highC != '*'))) {
                return false;
            } else {
                continue;
            }
          }
      }
      // check each row for the points below
      if (diffy > 0) {
        for (int i = curry + 1; i < othery; i++) {
            x1 = currx + ((i - curry)/slope);       // point of intersection on x axis 
            // check if x1 is an integer
            int x1Low = floor(x1);
            int x1High = ceil(x1);
            if (x1Low == y1 && x1High == x1) {                  // this point is exactly aligned with curr pos and other pos
                exactC = grid_get(full, x1, i);
                if ((exactC == '.') || (isalpha(exactC)) || (exactC == '*')) {
                    continue;
                } else {
                    return false;       // if not see through it directly blocks visibility
                }
            } else {
                lowC = grid_get(full, x1Low, i);
                highC = grid_get(full, x1High, i);
                // if the above character is blocking vision and the below character is blocking vision return false
                if ( ((lowC != '.') && (!isalpha(lowC)) && (lowC != '*')) && ((highC != '.') && (!isalpha(highC)) && (highC != '*'))) {
                    return false;
                } else {
                    continue;
                }
            }
        }
        // check each row for the points above 
      } else {
        for (int i = curry - 1; i > othery; i--) {
            x1 = currx + ((i - curry)/slope);
            // check if x1 is an integer
            int x1Low = floor(x1);
            int x1High = ceil(x1);
            if (x1Low == y1 && x1High == x1) {                  // this point is exactly aligned with curr pos and other pos
                exactC = grid_get(full, x1, i);
                if ((exactC == '.') || (isalpha(exactC)) || (exactC == '*')) {
                    continue;
                } else {
                    return false;
                }
            } else {
                lowC = grid_get(full, x1Low, i);
                highC = grid_get(full, x1High, i);
                // if the above character is blocking vision and the below character is blocking vision return false
                if ( ((lowC != '.') && (!isalpha(lowC)) && (lowC != '*')) && ((highC != '.') && (!isalpha(highC)) && (highC != '*'))) {
                    return false;
                } else {
                    continue;
                }
            }
        }
      }
      return true;
    }
    return false;
}



/****************** grid_visible ***************/
/* updates the player's visible grid based on their new location */
void
grid_visible(grid_t* full, int currx, int curry, grid_t* visible, char oldSpot){
    int nr = visible->nr;
    int nc = visible->nc;
    // iterate through every character in the visible grid
    for ( int i=0; i < nr; i++ ) {
        for ( int j=0; j < nc; j++ ) {
            // reset to old spot value if we used to be here
            if (grid_get(visible, j, i) == '@') {
                grid_set(visible, j, i, oldSpot);
            }
            // reset all *s to .
            if (grid_get(visible, j, i) == '*') {
                grid_set(visible, j, i, '.');
            }
            // if the point is visible then add it to the visible map
             if (grid_isVisible(full, currx, curry, j, i)) {
               char realChar = grid_get(full, j, i);
               grid_set(visible, j, i, realChar);
            } 
            // if the point is our current location add an '@'
            if ((j == currx) && (i == curry)) {
                grid_set(visible, j, i, '@');
            }
        }
    }
}

/****************** grid_nc ******************/
/* get the number of columns in a grid */
int
grid_nc(grid_t* grid) {
    return grid->nc;
}

/***************** grid_nr *****************/
/* get the number of rows in a grid */
int
grid_nr(grid_t* grid) {
    return grid->nr;
}

/***************** grid_valid ***************/
/* return if a character in a grid is a ., # or * character */
bool
grid_valid(grid_t* grid, int x, int y){
    char c = grid_get(grid, x, y);      // get the character
    if ((c == '.') || (c == '#') || (c == '*') || (isalpha(c)))  {  //check if it is a valid character
        return true;
    }
    return false;
}

/***************** grid_getString **************/
/* return the grid's char ** map as a string */
char*
grid_getString(grid_t* grid) {
    int nr = grid->nr;
    int nc = grid->nc;
    int size = nc * nr;
    int index = 0;
    int newLines = 0;

    char* gridString = malloc(size * sizeof(char) + 1 + nr);    // size is the number of characters (nc x nr) plus space for new lines characters after each row

    if (gridString == NULL) {   // check the malloc
        return NULL;
    }

 // for each char in the array calculate the appropriate index and add it to the gridString
    for (int i = 0; i < nr; i++) {
        for (int j = 0; j < nc; j++) {
            // calculate the index position
            index = newLines + i * nc + j;      //how many new lines we have added plus the index (column number x number in each column plus row number)
            gridString[index] = grid_get(grid, j, i);   // place character in index position

            if (j == (nc - 1)){
                gridString[index+1] = '\n';     // add a newline if its the last char in column
            }
        }
        newLines++;     // keep track of new lines added
    }
    gridString[size+newLines] = '\0';   // end the string with \0

    return gridString;
}

/***************** grid_delete **************/
/* free the memory allocated in grid creation */
void
grid_delete(grid_t* grid){

  if (grid == NULL) {
    return;
  }
    int nr = grid->nr;

    char** stringPointer = grid->map;
    if (stringPointer != NULL) {
      for ( int i = 0; i < nr; i++ ) {  // for each row 
        char* string = grid->map[i];
        if (string != NULL) {       // as long as there's a string there, free it 
          free(string);
        }
      }
      free(stringPointer);      // free the pointers to the strings 
      }

    free(grid); 

}
/******************* grid_print ***************/
/* print the grid -- only used for testing */
void
grid_print(grid_t* grid) {
    int nr = grid->nr;
    int nc = grid->nc;
    
    for (int i = 0; i < nr; i++){
        for (int j = 0; j < nc; j++) {
            printf("%c", grid->map[i][j]);
        }                        
            printf("\n");
    }
}


