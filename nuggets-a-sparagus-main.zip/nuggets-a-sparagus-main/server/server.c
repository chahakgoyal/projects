/*
 * a-sparagus, June 2021
 * server.c - server for nuggets game that sends messages to the client
 * and handles inputs from the client and makes use of
 * game.c module which depends on player.c and grid.c
 */

#include "../support/message.h"
#include "../support/log.h"
#include "../game/grid.h"
#include "../game/player.h"
#include "../game/game.h"
#include "../support/mem.h"
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>



/******** defining functions *********/
void parseArgs(const int argc, char* argv[], char** filename, int seed);
void updateGrid(game_t* game);
void displayResults(game_t* game, char* stats);
int main(const int argc, char* argv[]);
/**** local functions ****/
static bool handleMessage(void* arg, const addr_t from, const char* message);
static char* statistics(void);

/**** global variable ****/
game_t* game;


/***** functions *****/

/******* parseArgs - parse arguments *******/
void parseArgs(const int argc, char* argv[], char** filename, int seed) {
  // number of arguments should be between 2 and 3
  if (argc >= 2 && argc <= 3) {
    FILE* fp;
    // open up the file
    fp = fopen(*filename, "r");
    // check if file is NULL
    if (fp == NULL) {
      // exit non-zero
      fprintf(stderr, "Cannot open file\n");
      exit(2);
    }

    // call srand on seed
    if (seed > 0) {
      srand(seed);
    } else {
      fprintf(stderr, "Seed must be a positive integer\n");
      exit(2);
    }
    fclose(fp);
  } else {        // if more than 3 arguments or less than 2 arguments
    fprintf(stderr, "Incorrect number of arguments\n");
    // exit non zero
    exit(2);
  }
}


/******* update_grid - everytime a player joins or moves, sends messages 
 *to all the players and the spectator so that they see the most updated version ********/
void updateGrid(game_t* game) {
  // for all the players
  for (int i = 0; i < game_numPlayers(game); i++) {
    // get their key (name in the game)
    char key = 'A' + i;
    // check if the player has quit the game or not
    if (game_playerActive(game, key)) {
      // get the address of the player client
      addr_t client = game_getAddress(game, key);
      // count the number of rows and columns
      int rows = game_nr(game);
      int columns = game_nc(game);
      char msg[100];
      // get the number of gold left in the game
      int goldL = game_gold(game);
      // send grid size to client
      sprintf(msg, "GRID %d %d", rows, columns);
      message_send(client, msg);
      // get the gold in player's purse
      int goldC = game_playerPurse(game, key);
      // get the gold in player's hand (gold just collected)
      int goldN = game_goldHistory(game);
      char m[100];
      // send the gold stats to the player
      sprintf(m, "GOLD %d %d %d", goldN, goldC, goldL);
      message_send(client, m);
      // get the latest grid of the player
      char* grid = game_playerGrid(game, key);
      char s[9 + strlen(grid)];
      // send the grid to be displayed to the player
      sprintf(s, "DISPLAY\n%s", grid);
      message_send(client, s);
      // free the grid
      free(grid);
    }
  }
  // if the game has a spectator
  if (game_spectator(game)) {
    // get the spectator's address
    addr_t spectator = game_getSpectator(game);
    // get the rows and columns of the grid
    int rows = game_nr(game);
    int columns = game_nc(game);
    char msg[100];
    // get the gold remaining in the game
    int goldL = game_gold(game);
    // send the grid size to the spectator
    sprintf(msg, "GRID %d %d", rows, columns);
    message_send(spectator, msg);
    char m[100];
    // send the gold stats to the spectator
    sprintf(m, "GOLD 0 0 %d", goldL);
    message_send(spectator, m);
    // send the full grid with players and gold piles to the spectator
    char* grid = game_grid(game);
    char s[9+strlen(grid)];
    sprintf(s, "DISPLAY\n%s", grid);
    message_send(spectator, s);
    // free the grid
    free(grid);
  }
}


/****** display_results *********/
/* displays the stats to all the players and the spectator */
void displayResults(game_t* game, char* stats) {
  char msg[20 + strlen(stats)];
  sprintf(msg, "QUIT Game over\n%s", stats);
  // for every player in the game
  for (int i = 0; i < game_numPlayers(game); i++) {
    char key = 'A' + i;
    // to all the players that stuck till the end of the game
    if (game_playerActive(game, key)) {
      // send the stats
      addr_t client = game_getAddress(game, key);
      message_send(client, msg);
    }
  }
  // send the stats to the spectator if it exists
  if (game_spectator(game)) {
    message_send(game_getSpectator(game), msg);
  }
}


/***** main *****/
int main(const int argc, char* argv[]) {
  if (argc == 2) {
    int randomSeed = (int) getpid();
    parseArgs(argc, argv, &argv[1], randomSeed);        // make seed if not given
  }
  else {
    int seed = atoi(argv[2]);
    parseArgs(argc, argv, &argv[1], seed);             // handle seed, if given
  }
  // initialize file
  FILE* fp;
  fp = fopen(argv[1], "r");
  // random number of gold piles
  int totalGold = 250;
  int numGoldPiles = rand()%(30 + 1 - 10) + 10;
  // init game
  game = game_new(fp, totalGold, numGoldPiles);
  // initializing client address
  addr_t socket;
  log_init(stderr);
  // init message module
  int port = message_init(stderr);
  if (port == 0) {
    fprintf(stderr, "Failure to initialize message module\n");
    return 2;
  }
  // start listening
  bool ok = message_loop(&socket, 0, NULL, NULL, handleMessage);
 
  // close the message module
  message_done();
  log_done();
  // close the file
  fclose(fp);
  // delete the game
  game_delete(game);
  // return 1 or 0
  return ok;
}


/**** local function - called in message_loop in main function ******/
/* handles messages from the client */
static bool handleMessage(void* arg, const addr_t from, const char* message) {
  addr_t* fromp = (addr_t*) arg;        // pointer to an address (where message is coming from)
  if (fromp == NULL) {  //check that client is not NULL
    log_v("handleMessage called with arg = NULL");
    return true;    // terminate the message loop
  }
  if (game_gold(game) > 0) {    //check if gold is left
    *fromp = from;  // from is now an addr_t
    // if this is a request to join from a player 
    if (strncmp(message, "PLAY ", strlen("PLAY ")) == 0) {    // "PLAY <playername>" 
      char *content = (char*)message + strlen("PLAY ");
      // check if game is full 
      if (game_numPlayers(game) == 26) {
        //update_grid(data[0], clients, spec);
        message_send(from, "QUIT Game is full, no more players can join");
      } else if (content == NULL) {
        //update_grid(data[0], clients, spec);
        message_send(from, "QUIT Sorry - you must provide player's name");      // this won't happen
      } else {
          // add the player 
        char* name = (char*)malloc(50);
        strcpy(name, content);
        // create player name
        for (int i = 0; i < strlen(name); i++) {
          if (!isgraph((int)name[i]) && !isblank((int)name[i])) {
            name[i] = '_';
          }
        }
        char playerLetter = 'A' + game_numPlayers(game);
        // tell them it's okay to join
        char okPlayer[5];
        sprintf(okPlayer, "OK %c", playerLetter);
        message_send(from, okPlayer);   
        // add player to the game
        game_newPlayer(game, playerLetter, from, name); 
        updateGrid(game);   // update grid and players
      }
    } else if (strncmp(message, "SPECTATE", strlen("SPECTATE")) == 0) {   //SPECTATE
      if (game_spectator(game)) {              // if there is already a spectator
        message_send(game_getSpectator(game), "QUIT You have been replaced by a new spectator");  // tell old spec they're out!
      } 
      game_setSpectator(game, from);         // new spectator
      updateGrid(game);   // update grid and spectator
    } else if (strncmp(message, "KEY ", strlen("KEY ")) == 0) {    //KEY c
      char* content = (char*) message + strlen("KEY ");       // content is now the keypress
      if (!game_isSpectator(game, from)) {                    // make sure it's not from a spectator 
        char letter = game_getPlayerKey(game, from);        // get the player key
        if (*content == 'k' || *content == 'j' || *content == 'l' || *content == 'h' || *content == 'y' || *content == 'u' || *content == 'b' || *content == 'n' || *content == 'K' || *content == 'J' || *content == 'L' || *content == 'H' || *content == 'Y' || *content == 'U' || *content == 'B' || *content == 'N') {
          game_update(game, letter, *content);     // game update based on action
          updateGrid(game);    // update grid and players and spectator
        } else if (*content == 'Q') {   // player wants to quit
          game_deletePlayer(game, letter);      // make the player inactive
          updateGrid(game);     // update grid and players and spectator
          message_send(from, "QUIT Thanks for playing!");     // thank the player who quit for playing
        } else {
          message_send(from, "ERROR invalid key");    // other keys will be treated as invalid
        }
      } else {             // keystroke from spectator
        if (*content == 'Q') {       // if spectator wants to quit
          game_deleteSpectator(game);      // delete the spectator
          message_send(from, "QUIT Thanks for watching");    // thank the spectator who quit for watching the game
        } else {
          message_send(from, "ERROR Invalid key");    // other keystrokes will be treated as invalid
        }
      }
    }
  } else {     // if all gold has been collected
    char* stats = statistics();    // collect the statistics
    displayResults(game, stats);   //displays results to the player
    free(stats);     // free the stats string
    return true;    // terminate the message loop
  }
  return false;   // keep looping
}



/***** local function statistics - collects stats of all players that played the game *******/
static char* statistics(void) {
  // allocate appropriate memory
  char* stats = (char*)malloc(58 * game_numPlayers(game));
  int currpos = 0;    // used to append the string instead of overwriting it
  for (int i = 0; i < game_numPlayers(game); i++) {     // for all the players who player the game
    char key = 'A' + i;        // get their key
    // get their name, key and the amount of gold they collected
    sprintf(stats + currpos, "%s %c %d\n", game_getName(game, key), key, game_playerPurse(game, key));
    currpos+=strlen(stats);
  }
  // return the stats
  return stats;
}



