# Group - a-sparagus
# Server

This subdirectory contains the files necessary to implement the server design of the nuggets game. It includes several files:
* server.c
* IMPLEMENTATION.md
* DESIGN.md
* Makefile

A user can initiate a game with a valid map, and recieve a port number that can then be given to the client or clients to initiate the game. The server implements all the broader game logic behind the nuggets game. Server uses provided modules message.h and log.h for networking capabilities. It creates a game and calls game functions to interact with the game. The game itself will call player and grid functions to operate those modules. 


## Compiling
To compile,
```
make
```

To clean,
```
make clean
```

Commandline arguments to initiate the program,
```
./server map.txt [seed]
```
