# Group - a-sparagus
# Nuggets

This repository contains the code for the CS50 "Nuggets" game, in which players explore a set of rooms and passageways in search of gold nuggets.
The rooms and passages are defined by a *map* loaded by the server at the start of the game.
The gold nuggets are randomly distributed in *piles* within the rooms.
Up to 26 players, and one spectator, may play a given game.
Each player is randomly dropped into a room when joining the game.
Players move about, collecting nuggets when they move onto a pile.
When all gold nuggets are collected, the game ends and a summary is printed.

## Materials provided

See the [support library](support/README.md) for some useful modules.

See the [maps](maps/README.md) for some draft maps.

### Subdirectories
> This repository contains several subdirectories, some of which were given to us beforehand and some of which we created to implement the game.

We created the [client](client/README.md) to allow a client to join the game as a *player* or *spectator*. It takes commandline arguments to initiate the display given from the server, then interacts with the user through keystrokes. 

We created a [game](game/README.md) module that makes the game and implements `player` and `grid` that save the information specific to each player and the information specific to the grid, respectively.

We use the [maps](maps/README.md) directory for a collection of sample maps that the server can then use to create the display to pass to the client. We also added a new map file called a-sparagus.txt that can be used to play the game.

We created a [server](server/README.md) to give a platform for users to join and play the game. It mainly utilizes the game module from the game subdirectory in initiating a map and handling all the logic associated with the game (player, movement, gold collection, visibility, etc.)

We utilize the [support](support/README.md) directory for the `message.h` module that has abstracted the message communication across Internet networks needed by our server and client. We also use this directory for the `log.h` module to log information to an output file. We also make use of other files like `mem.h` and `file.h`.

### Group Members

- Eve Wening
- Hermilla Fentaw
- Itish Goel
- Chahak Goyal
